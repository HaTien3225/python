import json


def load_categories():
    with open("data/categories.json", encoding="utf-8") as f:
        return json.load(f)


def load_product():
    with open("data/product.json",encoding="utf-8") as g:
        product =json.load(g)
        return product


if __name__=="__main__":
    print(load_product())